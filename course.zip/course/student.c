/**
 * @file student.c
 * @author tracy wang
 * @brief Student library for managing students, including definitions of student functions
 * @version 0.1
 * @date 2022-04-12
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Increases number of grades by 1 and then adds grade to the array of grades for the student
 * 
 * @param student (an instance of the Student struct)
 * @param grade (representd as a double)
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  
  // if there are no existing grades, dynamically allocate array for the new grade 
  // number of grades is incremented first, so if num_grades = 1 then it was 0 at the start
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));

  // otherwise reallocate array to be one element larger and insert new grade at the end
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}


/**
 * @brief Sums the grades for a student and divides by number of grades to give average
 * 
 * @param student (an instance of the Student struct)
 * @return double representing average grade
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}


/**
 * @brief Prints the information for a given student, including name, id, grades, average grade
 * 
 * @param student (an instance of the Student struct)
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}


/**
 * @brief Creates new student by randomly selecting from predefined first and last names, and randomly generating numbers for id and grades
 * 
 * @param grades (the number of grades to generate)
 * @return pointer to new student (instance of Student struct)
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  
  // randomly generate student name
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // randomly generate student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  // randomly generate grades for the inputted number of grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}