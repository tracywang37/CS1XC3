/**
 * @file course.h
 * @author tracy wang
 * @brief Course library for managing courses, including Course type definition and course function declarations
 * @version 0.1
 * @date 2022-04-12
 * 
 */

#include "student.h"
#include <stdbool.h>

 /**
  * Course type stores a course with: course name, course code, students, total number of students
  * 
  */
typedef struct _course 
{
  char name[100]; /**< the course name */
  char code[10]; /**< the course code */
  Student *students; /**< pointer to array of the students in the course */
  int total_students; /**< the number of students in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


