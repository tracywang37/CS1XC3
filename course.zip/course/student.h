/**
 * @file student.h
 * @author tracy wang
 * @brief Student library for managing students, including Student type definition and student function declarations
 * @version 0.1
 * @date 2022-04-12
 * 
 */


/**
 * Student type stores a student with: first name, last name, id, grades, number of grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's id */
  double *grades; /**< pointer to array of the student's grades */
  int num_grades; /**< the student's total number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
