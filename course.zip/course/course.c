/**
 * @file course.c
 * @author tracy wang
 * @brief Course library for managing courses, including definitions of course functions
 * @version 0.1
 * @date 2022-04-12
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief Increases total students by 1 and then adds student to the array of students for the course 
 * 
 * @param course (an instance of the Course struct)
 * @param student (an instance of the Student struct)
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;

  // if there are no enrolled students, dynamically allocate array for the new student 
  // total students is incremented first, so if total_students = 1 then it was 0 at the start
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }

  // otherwise reallocate array to be one element larger and insert new student at the end
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}


/**
 * @brief Prints the information for a given course, including name, course code, total students, information for each student
 * 
 * @param course (an instance of the Course struct)
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}


/**
 * @brief Finds student with highest average grade in course
 * 
 * @param course (an instance of the Course struct)
 * @return pointer to student (instance of Student struct)
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    // call student library method for average grade of each student
    // if student's average is greater than highest average, it becomes new highest average and student becomes top student
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}


/**
 * @brief Finds students with passing average grade and adds them to dynamically allocated array
 * 
 * @param course (an instance of the Course struct)
 * @param number of passing students (pass by pointer)
 * @return pointer to array of students (instances of Student struct)
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}